1. code: contains code for Q1 and Q2. 
	run q1_main.m and q2_main.m respectively

2. report:
	Please read reports in html format for better image
	resoulution. PDF format creates smaller images. 
	"report/Q1" contains report in html as well as pdf format 
	for Q1.
	"report/Q2" contains report in html as well as pdf format 
	for Q2.

3. results:
	"results/Q1" contains full resolution images of plots of Q1				
	"results/Q2" contains full resolution images of plots of Q2